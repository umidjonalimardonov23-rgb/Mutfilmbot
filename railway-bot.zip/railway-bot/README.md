# 🎬 MagicMultBot — Railway Deploy

Telegram multfilm boti. Foydalanuvchilar kod yuboradi, bot esa videoni qaytaradi.

---

## Railway ga Deploy qilish

### 1. PostgreSQL qo'shish
Railway dashboard → **New** → **Database** → **PostgreSQL** → Add

### 2. Environment Variables
Railway dashboard → botingiz → **Variables** tabiga quyidagilarni kiriting:

| O'zgaruvchi | Qiymat | Misol |
|---|---|---|
| `BOT_TOKEN` | BotFather dan olingan token | `8902855419:AAE...` |
| `CHANNEL_ID` | Multfilm kanal username yoki ID | `@mutfilmUZcode` |
| `ADMIN_IDS` | Admin Telegram ID(lari) | `8787603995` |
| `DATABASE_URL` | Railway avtomatik to'ldiradi | — |

> ⚠️ `DATABASE_URL` ni Railway o'zi qo'shadi, siz qo'shmasligingiz kerak.

### 3. Deploy
```bash
# GitHub ga push qiling, Railway avtomatik deploy qiladi
# YOKI Railway CLI orqali:
railway up
```

---

## Mahalliy ishga tushirish

```bash
npm install
cp .env.example .env
# .env faylini tahrirlang
npm run dev
```

---

## Bot imkoniyatlari

### Foydalanuvchilar uchun:
- `/start` — Xush kelibsiz xabari
- Kod yuborish (misol: `049`) → Video keladi
- Minutiga 10 ta so'rov cheklovi

### Admin uchun:
- `/admin` — Admin panel ro'yxati
- `/upload` — Yangi multfilm yuklash (8 bosqich)
- `/stats` — Bot statistikasi
- `/broadcast <matn>` — Hammaga xabar yuborish
- `/ban <user_id>` — Foydalanuvchini bloklash
- `/unban <user_id>` — Blokdan chiqarish
- `/delete <KOD>` — Multfilmni o'chirish

### Video yuklash jarayoni (/upload):
1. Posterni yuboring (yoki /skip)
2. Videoni yuboring
3. Nom kiriting
4. Yil kiriting
5. Sifatni tanlang
6. IMDb reyting
7. Davlat
8. Audio tili
9. Janrlar

Tayyor! Bot avtomatik kaналga yuboradi va kod beradi.

---

## Muhim eslatma

Botni **@mutfilmUZcode** kanalida **Admin** qilib qo'ying:
- Kanalga kiring → Administrators → Add Administrator → @MagicMultBot
- Ruxsatlar: **Post Messages** ✅

---

## Texnologiyalar
- Node.js + TypeScript
- Telegraf (Telegram bot framework)
- Drizzle ORM + PostgreSQL
- Railway (hosting)
